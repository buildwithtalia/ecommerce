/**
 * Function to get all products from the eCommerce API.
 *
 * @returns {Promise<Object>} - The list of products from the API.
 */
const executeFunction = async () => {
  const baseUrl = ''; // will be provided by the user
  const accessToken = process.env.ECOMMERCE_FS_MCP_SERVER_REQUEST_GET_ALL_PRODUCTS_E8LCTNMD_ACCESSTOKEN
  try {
    // Construct the URL for the request
    const url = `${baseUrl}/products`;

    // Set up headers for the request
    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching products:', error);
    return {
      error: `An error occurred while fetching products: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for getting all products from the eCommerce API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_all_products',
      description: 'Get all products from the eCommerce API.',
      parameters: {
        type: 'object',
        properties: {},
        required: []
      }
    }
  }
};

export { apiTool };