/**
 * Function to get all orders from the eCommerce API.
 *
 * @returns {Promise<Object>} - The result of the API call to get all orders.
 */
const executeFunction = async () => {
  const baseUrl = ''; // will be provided by the user
  const accessToken = process.env.ECOMMERCE_FS_MCP_SERVER_REQUEST_GET_ALL_ORDERS_OEYZS7G_ACCESSTOKEN
  try {
    // Construct the URL for the API request
    const url = `${baseUrl}/orders`;

    // Set up headers for the request
    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching orders:', error);
    return {
      error: `An error occurred while fetching orders: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for getting all orders from the eCommerce API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_all_orders',
      description: 'Retrieve all orders from the eCommerce API.',
      parameters: {
        type: 'object',
        properties: {},
        required: []
      }
    }
  }
};

export { apiTool };